import torch
print("GPU available:", torch.cuda.is_available())