import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D

# 定义满意度函数
def desirability(u, u_type, L=None, U=None, T=None, a=1, b=1, k=1, p=2):
    if u_type == 'larger':
        return 1 - np.exp(-a * (u - L))
    elif u_type == 'smaller':
        return np.exp(-b * (u - U))
    elif u_type == 'target':
        return np.exp(-k * np.abs(u - T)**p)
    else:
        raise ValueError("Invalid type")

# 定义三维Harrington函数
def harrington_3d(x, y, z):
    dx = desirability(x, 'larger', L=0)
    dy = desirability(y, 'smaller', U=10)
    dz = desirability(z, 'target', T=5)
    return (dx * dy * dz) ** (1/3)

# 生成数据
x = np.linspace(0, 10, 100)
y = np.linspace(0, 10, 100)
X, Y = np.meshgrid(x, y)
Z = harrington_3d(X, Y, 5)  # 假设z固定为5

# 绘制三维图像
fig = plt.figure()
ax = fig.add_subplot(111, projection='3d')
ax.plot_surface(X, Y, Z, cmap='viridis')

ax.set_xlabel('X')
ax.set_ylabel('Y')
ax.set_zlabel('D(x, y, z)')

plt.show()