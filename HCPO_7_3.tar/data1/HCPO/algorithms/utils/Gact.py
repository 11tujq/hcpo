from .distributions import Categorical, DiagGaussian
import torch.nn as nn
import torch

class GACTLayer(nn.Module):
    """
    MLP Module to compute guide_actions.
    :param guide_action_space: (gym.Space) guide_space.
    :param inputs_dim: (int) dimension of network input.
    :param use_orthogonal: (bool) whether to use orthogonal initialization.
    :param gain: (float) gain of the output layer of the network.
    """

    def __init__(self, guide_action_space, inputs_dim, use_orthogonal, gain, args=None):
        super(GACTLayer, self).__init__()
        self.mixed_action = False
        self.multi_discrete = False
        self.torch=torch

        guide_action_dim = guide_action_space.n
        self.guide_action_out = Categorical(inputs_dim, guide_action_dim, use_orthogonal, gain)





    def forward(self, x, deterministic=False):
        """
        Compute guide_action logprobs from given input.
        :param x: (torch.Tensor) input to network.

        :param deterministic: (bool) whether to sample from action distribution or return the mode.

        :return guide_action: (torch.Tensor) guide_action to take.
        :return guide_action_log_probs: (torch.Tensor) log probabilities of taken guide_action
        """


        guide_action_logits = self.guide_action_out(x)

        guide_action = guide_action_logits.mode() if deterministic else guide_action_logits.sample()
        guide_action_log_probs = guide_action_logits.log_probs(guide_action)


        return guide_action, guide_action_log_probs

    def get_probs(self, x):
        """
        Compute guide_action probabilities from inputs.
        :param x: (torch.Tensor) input to network.

        :return guide_action_probs: (torch.Tensor)
        """

        guide_action_logits = self.guide_action_out(x)
        guide_action_probs = guide_action_logits.probs()

        return guide_action_probs

    def evaluate_actions(self, x,guide_action,active_masks=None):
        """
        Compute log probability and entropy of given guide_action.
        :param x: (torch.Tensor) input to network.
        :param guide_action: (torch.Tensor) guide_action whose entropy and log probability to evaluate.

        :param active_masks: (torch.Tensor) denotes whether an agent is active or dead.

        :return guide_action_log_probs: (torch.Tensor) log probabilities of the input guide_action.
        :return guide_action_dist_entropy: (torch.Tensor) action distribution entropy for the given inputs.
        """

        guide_action_logits = self.guide_action_out(x)
        guide_action_log_probs = guide_action_logits.log_probs(guide_action)
        if active_masks is not None:
            if self.guide_action_type == "Discrete":
                guide_action_dist_entropy = (guide_action_logits.entropy() * active_masks.squeeze(-1)).sum() / active_masks.sum()
            else:
                guide_action_dist_entropy = (guide_action_logits.entropy() * active_masks).sum() / active_masks.sum()
        else:
            guide_action_dist_entropy = guide_action_logits.entropy().mean()


        return guide_action_log_probs, guide_action_dist_entropy

    def evaluate_guide_action_chatrpo(self, x, guide_action):
        """
        Compute log probability and entropy of given actions.
        :param x: (torch.Tensor) input to network.
        :param guide_action: (torch.Tensor) guide_action whose entropy and log probability to evaluate.

        :param active_masks: (torch.Tensor) denotes whether an agent is active or dead.

        :return guide_action_log_probs: (torch.Tensor) log probabilities of the input guide_action.
        :return guide_action_dist_entropy: (torch.Tensor) guide_action distribution entropy for the given inputs.
        """
        guide_action_logits = self.guide_action_out(x)
        guide_action_mu = guide_action_logits.mean
        guide_action_std = guide_action_logits.stddev
        guide_action_log_probs = guide_action_logits.log_probs(guide_action)
        all_probs = torch.softmax(guide_action_logits.logits, dim=-1)
        # 确保 guide_action 的维度适配，例如 (B,) -> (B, 1)
        guide_action_prob = all_probs.gather(-1, guide_action.long())

        guide_action_dist_entropy = guide_action_logits.entropy().mean()

        return guide_action_log_probs, guide_action_dist_entropy, guide_action_mu, guide_action_std, all_probs, guide_action_prob