import pandas as pd
import matplotlib.pyplot as plt

# 读取数据
df1 = pd.read_csv('/home/tuzhi/下载/chatrpo_eval_max.csv')
df2 = pd.read_csv('/home/tuzhi/下载/hatrpo_eval_max.csv')

# 应用指数平滑（alpha=0.816）
y1_smoothed = df1['Value'].ewm(alpha=0.1).mean()
y2_smoothed = df2['Value'].ewm(alpha=0.1).mean()

# 创建专业级图表
plt.figure(figsize=(12, 7))

# 绘制平滑后的曲线
plt.plot(df1['Step'], y1_smoothed,
         label='ChatRPO',
         linewidth=2.5,
         color='#2A5CAA',  # 专业蓝色
         alpha=0.9)

plt.plot(df2['Step'], y2_smoothed,
         label='HatRPO',
         linewidth=2.5,
         color='#C44D34',  # 专业橙色
         linestyle='--',
         alpha=0.9)

# 添加0.816参考线
plt.axhline(y=0.816,
            color='#666666',
            linestyle=':',
            linewidth=1.5,
            alpha=0.7,
            label='Reference 0.816')

# 图表美化
plt.title('Performance Comparison with Smoothing (α=0.816)',
          fontsize=14,
          pad=20)
plt.xlabel('Training Steps',
           fontsize=12,
           labelpad=10)
plt.ylabel('Smoothed Value',
           fontsize=12,
           labelpad=10)

# 设置坐标轴风格
plt.grid(True,
         color='#F0F0F0',
         linestyle='--',
         linewidth=0.8)
plt.gca().set_facecolor('#F8F8F8')  # 设置背景色

# 图例美化
plt.legend(frameon=True,
           framealpha=0.9,
           loc='lower right',
           fontsize=11)

# 调整边框
for spine in plt.gca().spines.values():
    spine.set_color('#D0D0D0')
    spine.set_linewidth(1.2)

# 显示图表
plt.tight_layout()
plt.show()