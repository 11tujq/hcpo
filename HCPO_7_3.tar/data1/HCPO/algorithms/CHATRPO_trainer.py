import numpy as np
import torch
import torch.nn as nn
from utils.util import get_gard_norm, huber_loss, mse_loss
from utils.popart import PopArt
from algorithms.utils.util import check
from algorithms.actor_coach_critic import Actor,Coach

class CHATRPO:
    """
    Trainer class for CHATRPO to update policies.
    :param args: (argparse.Namespace) arguments containing relevant model, policy, and env information.
    :param policy: (HATRPO_Policy) policy to update.
    :param  device: (torch.device) specifies the device to run on (cpu/gpu).
    """

    def __init__(self,
                 args,
                 policy,
                 device=torch.device("cpu")):

        self.device = device
        self.tpdv = dict(dtype=torch.float32, device=device)
        self.policy = policy

        self.clip_param = args.clip_param
        self.num_mini_batch = args.num_mini_batch
        self.data_chunk_length = args.data_chunk_length  # 数据片段长度
        self.value_loss_coef = args.value_loss_coef
        self.entropy_coef = args.entropy_coef  # 损失系数
        self.max_grad_norm = args.max_grad_norm  # 最大梯度范数
        self.huber_delta = args.huber_delta

        self.kl_threshold = args.kl_threshold  # kl阈值
        self.guide_action_kl_threshold = args.guide_action_kl_threshold
        self.ls_step = args.ls_step  # 线搜索步长
        self.accept_ratio = args.accept_ratio

        self._use_recurrent_policy = args.use_recurrent_policy
        self._use_naive_recurrent = args.use_naive_recurrent_policy
        self._use_max_grad_norm = args.use_max_grad_norm
        self._use_clipped_value_loss = args.use_clipped_value_loss
        self._use_huber_loss = args.use_huber_loss
        self._use_popart = args.use_popart
        self._use_value_active_masks = args.use_value_active_masks
        self._use_policy_active_masks = args.use_policy_active_masks

        if self._use_popart:
            self.value_normalizer = PopArt(1, device=self.device)
        else:
            self.value_normalizer = None  # 值函数规范化算法

    def cal_value_loss(self, values, value_preds_batch, return_batch, active_masks_batch):
        """
        Calculate value function loss.
        :param values: (torch.Tensor) value function predictions.
        :param value_preds_batch: (torch.Tensor) "old" value  predictions from data batch (used for value clip loss)
        :param return_batch: (torch.Tensor) reward to go returns.
        :param active_masks_batch: (torch.Tensor) denotes if agent is active or dead at a given timesep.

        :return value_loss: (torch.Tensor) value function loss.
        """
        if self._use_popart:
            value_pred_clipped = value_preds_batch + (values - value_preds_batch).clamp(-self.clip_param,
                                                                                        self.clip_param)
            error_clipped = self.value_normalizer(return_batch) - value_pred_clipped
            error_original = self.value_normalizer(return_batch) - values
        else:
            value_pred_clipped = value_preds_batch + (values - value_preds_batch).clamp(-self.clip_param,
                                                                                        self.clip_param)
            error_clipped = return_batch - value_pred_clipped
            error_original = return_batch - values

        if self._use_huber_loss:
            value_loss_clipped = huber_loss(error_clipped, self.huber_delta)
            value_loss_original = huber_loss(error_original, self.huber_delta)
        else:
            value_loss_clipped = mse_loss(error_clipped)
            value_loss_original = mse_loss(error_original)

        if self._use_clipped_value_loss:
            value_loss = torch.max(value_loss_original, value_loss_clipped)
        else:
            value_loss = value_loss_original

        if self._use_value_active_masks:
            value_loss = (value_loss * active_masks_batch).sum() / active_masks_batch.sum()
        else:
            value_loss = value_loss.mean()

        return value_loss

    def flat_grad(self, grads):
        grad_flatten = []
        for grad in grads:
            if grad is None:
                continue
            grad_flatten.append(grad.view(-1))
        grad_flatten = torch.cat(grad_flatten)
        return grad_flatten  # 展平梯度

    def flat_hessian(self, hessians):
        hessians_flatten = []
        for hessian in hessians:
            if hessian is None:
                continue
            hessians_flatten.append(hessian.contiguous().view(-1))
        hessians_flatten = torch.cat(hessians_flatten).data
        return hessians_flatten  # 展平hessians矩阵

    def flat_params(self, model):
        params = []
        for param in model.parameters():
            params.append(param.data.view(-1))
        params_flatten = torch.cat(params)
        return params_flatten  # 展平模型参数

    def update_model(self, model, new_params):
        index = 0
        for params in model.parameters():
            params_length = len(params.view(-1))
            new_param = new_params[index: index + params_length]
            new_param = new_param.view(params.size())
            params.data.copy_(new_param)
            index += params_length

    def kl_approx(self, q, p):
        r = torch.exp(p - q)
        kl = r - 1 - p + q
        return kl

    def guide_action_kl_divergence(self, cent_obs,guide_action, new_coach, old_coach):
        _, _, mu, std, probs,_= new_coach.evaluate_guide_action(cent_obs, guide_action)
        _, _, mu_old, std_old, probs_old,_= old_coach.evaluate_guide_action(cent_obs,guide_action)


        probs_old = probs_old.detach()
        guide_action_kl = self.kl_approx(probs_old, probs)
        

        return guide_action_kl

    def action_kl_divergence(self, cent_obs,obs,guide_action, rnn_states, action, masks, available_actions, active_masks, new_actor, old_actor,coach):

        _, _, mu, std, probs = new_actor.evaluate_actions(obs,guide_action, rnn_states, action, masks, available_actions,
                                                          active_masks)


        _, _, mu_old, std_old, probs_old = old_actor.evaluate_actions(obs, guide_action,rnn_states, action, masks, available_actions,
                                                                      active_masks)
        _, _, _, _, prob_,guide_action_prob= coach.evaluate_guide_action(cent_obs, guide_action)
         # 形状从 [75] 变为 [75, 1]
        if mu.grad_fn==None:
            


            probs_old = probs_old.detach()
            action_kl = self.kl_approx(probs_old, probs)
            action_kl=action_kl*guide_action_prob
        else:
            n_actions = probs.size(-1)  # 直接取最后一个维度
            guide_action_prob = guide_action_prob.repeat(1, n_actions)
            mu_old = mu_old.detach()


            logstd = torch.log(std)
            std_old = std_old.detach()
            logstd_old = torch.log(std_old)

            # action_kl divergence between old policy and new policy : D( pi_old || pi_new )
            # pi_old -> mu0, logstd0, std0 / pi_new -> mu, logstd, std
            # be careful of calculating KL-divergence. It is not symmetric metric
            action_kl = guide_action_prob*(logstd - logstd_old + (std_old.pow(2) + (mu_old - mu).pow(2)) / (2.0 * std.pow(2)) - 0.5)
        if len(action_kl.shape)>1:
            action_kl=action_kl.sum(1, keepdim=True)


        return action_kl

    # from openai baseline code
    # https://github.com/openai/baselines/blob/master/baselines/common/cg.py
    def guide_action_fisher_vector_product(self, coach, cent_obs, guide_action, p):

        p.detach()
        kl = self.guide_action_kl_divergence(cent_obs, guide_action, new_coach=coach,
                                old_coach=coach)

        kl = kl.mean()
        kl_grad = torch.autograd.grad(kl, coach.parameters(), create_graph=True, allow_unused=True)
        kl_grad = self.flat_grad(kl_grad)  # check kl_grad == 0

        kl_grad_p = (kl_grad * p).sum()
        kl_hessian_p = torch.autograd.grad(kl_grad_p, coach.parameters(), allow_unused=True)
        kl_hessian_p = self.flat_hessian(kl_hessian_p)
        return kl_hessian_p + 0.1 * p


    def action_fisher_vector_product(self, actor, cent_obs,obs, guide_action, rnn_states, action, masks, available_actions,
                                     active_masks,coach, p):

        p.detach()
        kl = self.action_kl_divergence(cent_obs,obs, guide_action, rnn_states, action, masks, available_actions, active_masks,
                                       new_actor=actor,
                                       old_actor=actor,
                                       coach=coach)


        kl = kl.mean()
        kl_grad = torch.autograd.grad(kl, actor.parameters(), create_graph=True, allow_unused=True)

        kl_grad = self.flat_grad(kl_grad)  # check kl_grad == 0
        kl_grad_p = (kl_grad * p).sum()
        kl_hessian_p = torch.autograd.grad(kl_grad_p, actor.parameters(), allow_unused=True)
        kl_hessian_p = self.flat_hessian(kl_hessian_p)
        return kl_hessian_p + 0.1 * p

    def guide_action_conjugate_gradient(self, coach, cent_obs, guide_action,a, nsteps,
                                        residual_tol=1e-10):
        x = torch.zeros(a.size()).to(device=self.device)
        r = a.clone()
        p = a.clone()

        rdotr = torch.dot(r, r)
        for i in range(nsteps):
            _Avp = self.guide_action_fisher_vector_product(coach, cent_obs,guide_action, p)
            alpha = rdotr / torch.dot(p, _Avp)
            x += alpha * p
            r -= alpha * _Avp
            new_rdotr = torch.dot(r, r)
            betta = new_rdotr / rdotr
            p = r + betta * p
            rdotr = new_rdotr
            if rdotr < residual_tol:
                break
        return x

    def action_conjugate_gradient(self, actor,coach,cent_obs,obs, guide_action,rnn_states, action, masks, available_actions, active_masks, b, nsteps,
                           residual_tol=1e-10):
        x = torch.zeros(b.size()).to(device=self.device)
        r = b.clone()
        p = b.clone()

        rdotr = torch.dot(r, r)
        for i in range(nsteps):
            _Avp = self.action_fisher_vector_product(actor, cent_obs,obs,guide_action, rnn_states, action, masks, available_actions, active_masks,coach, p)
            alpha = rdotr / torch.dot(p, _Avp)
            x += alpha * p
            r -= alpha * _Avp
            new_rdotr = torch.dot(r, r)
            betta = new_rdotr / rdotr
            p = r + betta * p
            rdotr = new_rdotr
            if rdotr < residual_tol:
                break
        return x



    def chatrpo_update(self, sample, update_actor=True):
        """
        Update actor and critic networks.
        :param sample: (Tuple) contains data batch with which to update networks.
        :update_actor: (bool) whether to update actor network.

        :return value_loss: (torch.Tensor) value function loss.
        :return critic_grad_norm: (torch.Tensor) gradient norm from critic update.
        ;return policy_loss: (torch.Tensor) actor(policy) loss value.
        :return dist_entropy: (torch.Tensor) action entropies.
        :return actor_grad_norm: (torch.Tensor) gradient norm from actor update.
        :return imp_weights: (torch.Tensor) importance sampling weights.
        """
        share_obs_batch, obs_batch, rnn_states_batch, rnn_states_critic_batch, guide_action_batch,actions_batch, \
            value_preds_batch, Mvalues_preds_batch,return_batch, masks_batch, active_masks_batch, old_guide_action_log_probs_batch,old_action_log_probs_batch, \
            adv_targ1,adv_targ2 ,available_actions_batch, factor_batch1,factor_batch2= sample

        old_guide_action_log_probs_batch=check(old_guide_action_log_probs_batch).to(**self.tpdv)
        old_action_log_probs_batch = check(old_action_log_probs_batch).to(**self.tpdv)
        adv_targ1 = check(adv_targ1).to(**self.tpdv)
        adv_targ2 = check(adv_targ2).to(**self.tpdv)
        guide_action_batch = check(guide_action_batch).to(**self.tpdv)
        value_preds_batch = check(value_preds_batch).to(**self.tpdv)
        Mvalue_preds_batch = check(value_preds_batch).to(**self.tpdv)
        return_batch = check(return_batch).to(**self.tpdv)
        active_masks_batch = check(active_masks_batch).to(**self.tpdv)
        factor_batch1 = check(factor_batch1).to(**self.tpdv)
        factor_batch2 = check(factor_batch2).to(**self.tpdv)

        values, Mvalues,action_log_probs, dist_entropy, action_mu, action_std, _= self.policy.evaluate_actions(share_obs_batch,
                                                                                                        obs_batch,
                                                                                                        guide_action_batch,
                                                                                                        rnn_states_batch,
                                                                                                        rnn_states_critic_batch,
                                                                                                        actions_batch,
                                                                                                        masks_batch,
                                                                                                        available_actions_batch,
                                                                                                        active_masks_batch)
        guide_action_log_probs, guide_action_dist_entropy, guide_action_mu, guide_action_std, guide_action_all_probs ,_= self.policy.evaluate_guide_action(share_obs_batch,
                                                                                                                                                      guide_action_batch)

        # student update

        guide_action_logits = self.policy.evaluate_student(obs_batch)

        guide_action_tensor_batch = guide_action_batch.clone().detach()

        guide_action_tensor_batch = guide_action_tensor_batch.squeeze(1).long()
        student_loss = self.policy.criterion(guide_action_logits, guide_action_tensor_batch)
        self.policy.student_optimizer.zero_grad()
        student_loss.backward()
        # 参数更新
        self.policy.student_optimizer.step()

        # critic update
        value_loss = self.cal_value_loss(values, value_preds_batch, return_batch, active_masks_batch)

        self.policy.critic_optimizer.zero_grad()

        (value_loss * self.value_loss_coef).backward()

        if self._use_max_grad_norm:
            critic_grad_norm = nn.utils.clip_grad_norm_(self.policy.critic.parameters(), self.max_grad_norm)
        else:
            critic_grad_norm = get_gard_norm(self.policy.critic.parameters())

        self.policy.critic_optimizer.step()
        # mcritic update
        Mvalue_loss = self.cal_value_loss(Mvalues, Mvalue_preds_batch, return_batch, active_masks_batch)

        self.policy.mcritic_optimizer.zero_grad()

        (Mvalue_loss * self.value_loss_coef).backward()

        if self._use_max_grad_norm:
            mcritic_grad_norm = nn.utils.clip_grad_norm_(self.policy.critic.parameters(), self.max_grad_norm)
        else:
            mcritic_grad_norm = get_gard_norm(self.policy.critic.parameters())

        self.policy.mcritic_optimizer.step()

        #loss 策略梯度损失，factor是重要性权重
        # coach update
        ratio1 = torch.prod(torch.exp(guide_action_log_probs - old_guide_action_log_probs_batch), dim=-1, keepdim=True)

        loss1 = torch.sum(ratio1 * factor_batch1 * adv_targ1, dim=-1, keepdim=True).mean()

        loss_grad1 = torch.autograd.grad(loss1, self.policy.coach.parameters(), allow_unused=True)
        loss_grad1 = self.flat_grad(loss_grad1)

        guide_action_step_dir = self.guide_action_conjugate_gradient(self.policy.coach,
                                           share_obs_batch,
                                           guide_action_batch,
                                           loss_grad1.data,
                                           nsteps=10)

        loss1 = loss1.data.cpu().numpy()

        params = self.flat_params(self.policy.coach)
        guide_action_fvp = self.guide_action_fisher_vector_product(self.policy.coach,
                                         share_obs_batch,
                                         guide_action_batch,
                                         guide_action_step_dir)
        shs = 0.5 * (guide_action_step_dir * guide_action_fvp).sum(0, keepdim=True)
        step_size = 1 / torch.sqrt(shs / self.guide_action_kl_threshold)[0]
        full_step = step_size * guide_action_step_dir

        old_coach = Coach(self.policy.args,
                          self.policy.share_obs_space,
                          self.policy.guide_action_space,
                          self.device)
        self.update_model(old_coach, params)
        expected_improve1 = (loss_grad1 * full_step).sum(0, keepdim=True)
        expected_improve1 = expected_improve1.data.cpu().numpy()
        flag = False
        fraction = 1

        for i in range(self.ls_step):

            new_params = params + fraction * full_step
            self.update_model(self.policy.coach, new_params)

            guide_action_log_probs, guide_action_entropy, guide_action_mu, guide_action_std, guide_action_all_probs,_ = self.policy.coach.evaluate_guide_action(
                share_obs_batch,
                guide_action_batch
                )

            ratio1 = torch.exp(guide_action_log_probs - old_guide_action_log_probs_batch)
            new_loss1 = torch.sum(ratio1 * factor_batch1 * adv_targ1, dim=-1, keepdim=True).mean()

            new_loss1 = new_loss1.data.cpu().numpy()
            loss_improve1 = new_loss1 - loss1

            guide_action_kl= self.guide_action_kl_divergence(share_obs_batch,
                                           guide_action_batch,
                                           new_coach=self.policy.coach,
                                           old_coach=old_coach)

            guide_action_kl = guide_action_kl.mean()

            if guide_action_kl < self.guide_action_kl_threshold and (
                    loss_improve1 / expected_improve1) > self.accept_ratio and loss_improve1.item() > 0:
                flag = True
                break
            expected_improve1 *= 0.5
            fraction *= 0.5

        if not flag:
            params = self.flat_params(old_coach)
            self.update_model(self.policy.coach, params)
            print('coach policy update does not improve the surrogate')



        # actor update
        ratio2 = torch.prod(torch.exp(action_log_probs - old_action_log_probs_batch), dim=-1, keepdim=True)
        if self._use_policy_active_masks:
            loss2 = (torch.sum(ratio2 * factor_batch2 * adv_targ2, dim=-1, keepdim=True) *
                    active_masks_batch).sum() / active_masks_batch.sum()
        else:
            loss2 = torch.sum(ratio2* factor_batch2 * adv_targ2, dim=-1, keepdim=True).mean()

        loss_grad2 = torch.autograd.grad(loss2, self.policy.actor.parameters(), allow_unused=True)
        loss_grad2 = self.flat_grad(loss_grad2)

        step_dir = self.action_conjugate_gradient(self.policy.actor,
                                           old_coach,
                                           share_obs_batch,
                                           obs_batch,
                                           guide_action_batch,
                                           rnn_states_batch,
                                           actions_batch,
                                           masks_batch,
                                           available_actions_batch,
                                           active_masks_batch,
                                           loss_grad2.data,
                                           nsteps=10)

        loss2 = loss2.data.cpu().numpy()

        params = self.flat_params(self.policy.actor)
        fvp = self.action_fisher_vector_product(self.policy.actor,
                                         share_obs_batch,
                                         obs_batch,
                                         guide_action_batch,
                                         rnn_states_batch,
                                         actions_batch,
                                         masks_batch,
                                         available_actions_batch,
                                         active_masks_batch,
                                         self.policy.coach,
                                         step_dir)
        shs = 0.5 * (step_dir * fvp).sum(0, keepdim=True)
        step_size = 1 / torch.sqrt(shs / self.kl_threshold)[0]
        full_step = step_size * step_dir

        old_actor = Actor(self.policy.args,
                          self.policy.obs_space,
                          self.policy.act_space,
                          self.device)
        self.update_model(old_actor, params)
        expected_improve2 = (loss_grad2* full_step).sum(0, keepdim=True)
        expected_improve2 = expected_improve2.data.cpu().numpy()

        # Backtracking line search
        flag = False
        fraction = 1
        for i in range(self.ls_step):
            new_params = params + fraction * full_step
            self.update_model(self.policy.actor, new_params)
            values, Mvalues,action_log_probs, dist_entropy, action_mu, action_std, _ = self.policy.evaluate_actions(
                share_obs_batch,
                obs_batch,
                guide_action_batch,
                rnn_states_batch,
                rnn_states_critic_batch,
                actions_batch,
                masks_batch,
                available_actions_batch,
                active_masks_batch)

            ratio2 = torch.exp(action_log_probs - old_action_log_probs_batch)
            if self._use_policy_active_masks:
                new_loss2 = (torch.sum(ratio2 * factor_batch2 * adv_targ2, dim=-1, keepdim=True) *
                            active_masks_batch).sum() / active_masks_batch.sum()
            else:
                new_loss2 = torch.sum(ratio2* factor_batch2 * adv_targ2, dim=-1, keepdim=True).mean()

            new_loss2 = new_loss2.data.cpu().numpy()
            loss_improve2 = new_loss2 - loss2

            action_kl = self.action_kl_divergence(share_obs_batch,obs_batch,
                                    guide_action_batch,
                                    rnn_states_batch,
                                    actions_batch,
                                    masks_batch,
                                    available_actions_batch,
                                    active_masks_batch,
                                    new_actor=self.policy.actor,
                                    old_actor=old_actor,
                                    coach=old_coach)
            action_kl = action_kl.mean()

            if action_kl < self.kl_threshold and (
                    loss_improve2 / expected_improve2) > self.accept_ratio and loss_improve2.item() > 0:
                flag = True
                break
            expected_improve2 *= 0.5
            fraction *= 0.5

        if not flag:
            params = self.flat_params(old_actor)
            self.update_model(self.policy.actor, params)
            print('actor policy update does not improve the surrogate')




        return value_loss, Mvalue_loss,critic_grad_norm,mcritic_grad_norm,student_loss,guide_action_kl, action_kl,loss_improve1,loss_improve2, expected_improve1, expected_improve2,guide_action_dist_entropy,dist_entropy, ratio1,ratio2

    def train(self, buffer, update_actor=True):
        """
        Perform a training update using minibatch GD.
        :param buffer: (SharedReplayBuffer) buffer containing training data.
        :param update_actor: (bool) whether to update actor network.

        :return train_info: (dict) contains information regarding training update (e.g. loss, grad norms, etc).
        """
        if self._use_popart:
            advantages1 = self.value_normalizer.denormalize(buffer.Mvalue_preds[:-1]) - self.value_normalizer.denormalize(buffer.value_preds[:-1])
            advantages2 = buffer.returns[:-1] - self.value_normalizer.denormalize(buffer.Mvalue_preds[:-1])
        else:
            advantages1 = buffer.Mvalue_preds[:-1]-buffer.value_preds[:-1]
            advantages2 = buffer.returns[:-1] - buffer.Mvalue_preds[:-1]

        advantages1_copy = advantages1.copy()
        advantages1_copy[buffer.active_masks[:-1] == 0.0] = np.nan
        advantages2_copy = advantages2.copy()
        advantages2_copy[buffer.active_masks[:-1] == 0.0] = np.nan
        mean_advantages1 = np.nanmean(advantages1_copy)
        std_advantages1 = np.nanstd(advantages1_copy)
        advantages1 = (advantages1 - mean_advantages1) / (std_advantages1 + 1e-5)
        mean_advantages2 = np.nanmean(advantages2_copy)
        std_advantages2 = np.nanstd(advantages2_copy)
        advantages2= (advantages2 - mean_advantages2) / (std_advantages2 + 1e-5)

        train_info = {}

        train_info['value_loss'] = 0
        train_info['Mvalue_loss'] = 0
        train_info['critic_grad_norm'] = 0
        train_info['mcritic_grad_norm'] = 0
        train_info['student_loss'] = 0
        train_info['guide_action_kl'] = 0
        train_info['action_kl'] = 0
        train_info['loss_improve1'] = 0
        train_info['loss_improve2'] = 0
        train_info['expected_improve1'] = 0
        train_info['expected_improve2'] = 0
        train_info['guide_action_dist_entropy'] = 0
        train_info['dist_entropy'] = 0
        train_info['ratio1'] = 0
        train_info['ratio2'] = 0

        if self._use_recurrent_policy:
            data_generator = buffer.recurrent_generator(advantages1, advantages2, self.num_mini_batch, self.data_chunk_length)
        elif self._use_naive_recurrent:
            data_generator = buffer.naive_recurrent_generator(advantages1, advantages2, self.num_mini_batch)
        else:
            data_generator = buffer.feed_forward_generator(advantages1, advantages2, self.num_mini_batch)

        for sample in data_generator:

            value_loss, Mvalue_loss,critic_grad_norm,mcritic_grad_norm,student_loss,guide_action_kl, action_kl,loss_improve1,loss_improve2, expected_improve1, expected_improve2,guide_action_dist_entropy,dist_entropy, ratio1,ratio2\
                = self.chatrpo_update(sample, update_actor)
            train_info['Mvalue_loss'] += Mvalue_loss.item()
            train_info['student_loss'] += student_loss.item()
            train_info['critic_grad_norm'] += critic_grad_norm
            train_info['mcritic_grad_norm'] += mcritic_grad_norm
            train_info['guide_action_kl'] += guide_action_kl
            train_info['action_kl'] += action_kl
            train_info['loss_improve1'] += loss_improve1
            train_info['loss_improve2'] += loss_improve2
            train_info['expected_improve1'] += expected_improve1
            train_info['expected_improve2'] += expected_improve2
            train_info['guide_action_dist_entropy'] += guide_action_dist_entropy
            train_info['dist_entropy'] += dist_entropy
            train_info['ratio1'] += ratio1.mean()
            train_info['ratio2'] += ratio2.mean()
            train_info['value_loss'] += value_loss.item()

        num_updates = self.num_mini_batch
        #给每一个数据求平均
        for k in train_info.keys():
            train_info[k] /= num_updates

        return train_info
    print()
    def prep_training(self):
        self.policy.actor.train()
        self.policy.critic.train()
        self.policy.coach.train()
        self.policy.student.train()
        self.policy.mcritic.train()

    def prep_rollout(self):
        self.policy.actor.eval()
        self.policy.critic.eval()
        self.policy.coach.eval()
        self.policy.student.eval()
        self.policy.mcritic.eval()
