import torch
if torch.cuda.is_available():
    print('dsada')
    print("GPU available:", torch.cuda.is_available())
    # 返回可用的 GPU 数量
    print("GPU count:", torch.cuda.device_count())
else:
    print('gg')