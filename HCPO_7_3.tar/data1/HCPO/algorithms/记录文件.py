if algo_args["algo"]["module_type"] == "Discrete":
    module_actions_num = algo_args["algo"].get("module_actions_num", 10)
    module_space = gym.spaces.Discrete(module_actions_num)
else:
    module_space = gym.spaces.Box(low=-1, high=1, shape=(1,), dtype=np.float32)
self.module_actor = ALGO_REGISTRY[algo_args["algo"]["algo_h"]](
    {**algo_args["model"], **algo_args["algo"]},
    self.envs.observation_space[0],
    module_space,
    self.num_agents,
    device=self.device,
)
(TRPO) tuzhi@tuzhi-WP:~/下载/TRPO-in-MARL-master/scripts$ export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/home/tuzhi/.mujoco/mujoco200/bin
(TRPO) tuzhi@tuzhi-WP:~/下载/TRPO-in-MARL-master/scripts$ export LD_PRELOAD=/usr/lib/x86_64-linux-gnu/libGLEW.so

share_obs_batch, obs_batch, rnn_states_batch, rnn_states_critic_batch, guide_action_batch, actions_batch, \
    value_preds_batch, return_batch, masks_batch, active_masks_batch, old_guide_action_log_probs_batch, old_action_log_probs_batch, \
    adv_targ, available_actions_batch, factor_batch = sample
guide_action_all_probs
share_obs_batch, obs_batch, rnn_states_batch, rnn_states_critic_batch, guide_action_batch, actions_batch, \
    value_preds_batch, return_batch, masks_batch, active_masks_batch, old_guide_action_log_probs_batch, old_action_log_probs_batch, \
    adv_targ1, adv_targ2, available_actions_batch, factor_batch = sample
export LD_LIBRARY_PATH(TRPO) tuzhi@tuzhi-WP:~/下载/TRPO-in-MARL-master$ =$LD_LIBRARY_PATH:/home/tuzhi/.mujoco/mujoco200/bin
(TRPO) tuzhi@tuzhi-WP:~/下载/TRPO-in-MARL-master$ export LD_PRELOAD=/usr/lib/x86_64-linux-gnu/libGLEW.so
export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/root/mujoco/mujoco200/bin
export MUJOCO_KEY_PATH=~/.mujoco${MUJOCO_KEY_PATH}
python -m tensorboard.main --logdir=results/mujoco/Ant-v2/chatrpo/mlp/1/run209/logs/
python -m tensorboard.main --logdir=results/mujoco/Ant-v2/hatrpo/mlp/1/run6/logs/