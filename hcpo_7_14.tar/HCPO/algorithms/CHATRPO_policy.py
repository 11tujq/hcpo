import torch
from algorithms.actor_coach_critic import Actor, Critic,Coach,Student,Mcritic
from utils.util import update_linear_schedule


class CHATRPO_Policy:
    """
    CHATRPO Policy  class. Wraps actor and critic and networks to compute actions and guide_action and value function predictions.

    :param args: (argparse.Namespace) arguments containing relevant model and policy information.
    :param obs_space: (gym.Space) observation space.
    :param cent_obs_space: (gym.Space) value function input space .
    :param act_space: (gym.Space) action space.
    :param guide_action_space:(gym.space)guide_action space
    :param device: (torch.device) specifies the device to run on (cpu/gpu).
    """

    def __init__(self, args, obs_space, cent_obs_space, act_space, guide_action_space,device=torch.device("cpu")):
        self.args=args
        self.device = device
        self.lr = args.lr

        self.critic_lr = args.critic_lr

        self.opti_eps = args.opti_eps
        self.weight_decay = args.weight_decay

        self.obs_space = obs_space
        self.share_obs_space = cent_obs_space
        self.act_space = act_space
        self.guide_action_space=guide_action_space

        self.coach=Coach(args, self.share_obs_space, self.guide_action_space, self.device)
        self.actor = Actor(args, self.obs_space, self.act_space, self.device)
        self.student=Student(args, self.obs_space, self.guide_action_space, self.device)
        ######################################Please Note#########################################
        #####   We create one critic for each agent, but they are trained with same data     #####
        #####   and using same update setting. Therefore they have the same parameter,       #####
        #####   you can regard them as the same critic.                                      #####
        ##########################################################################################
        self.critic = Critic(args, self.share_obs_space, self.device)
        self.mcritic=Mcritic(args, self.share_obs_space, self.device)


        self.critic_optimizer = torch.optim.Adam(self.critic.parameters(),
                                                 lr=self.critic_lr,
                                                 eps=self.opti_eps,
                                                 weight_decay=self.weight_decay)
        self.mcritic_optimizer = torch.optim.Adam(self.mcritic.parameters(),
                                                 lr=self.critic_lr,
                                                 eps=self.opti_eps,
                                                 weight_decay=self.weight_decay)

        self.criterion = torch.nn.CrossEntropyLoss()
        self.student_optimizer =  torch.optim.Adam(self.student.parameters(),
                                                 lr=self.lr,
                                                 eps=self.opti_eps,
                                                 weight_decay=self.weight_decay)
    def lr_decay(self, episode, episodes):
        """
        Decay the actor and critic and coach learning rates.
        :param episode: (int) current training episode.
        :param episodes: (int) total number of training episodes.
        """
        update_linear_schedule(self.coach_optimizer, episode, episodes, self.coach_lr)
        update_linear_schedule(self.actor_optimizer, episode, episodes, self.lr)
        update_linear_schedule(self.critic_optimizer, episode, episodes, self.critic_lr)#线性衰减的学习率
    def get_guide_action(self,cent_obs,deterministic=False):
        guide_action, guide_action_log_probs = self.coach(cent_obs,deterministic)
        return guide_action, guide_action_log_probs
#用来在训练的时候得到动作，价值等，collect函数

    def get_actions(self, cent_obs, obs, rnn_states_actor, rnn_states_critic, masks, available_actions=None,
                    deterministic=False):
        """
        Compute actions and value function predictions for the given inputs.
        :param cent_obs (np.ndarray): centralized input to the critic.
        :param obs (np.ndarray): local agent inputs to the actor.
        :param rnn_states_actor: (np.ndarray) if actor is RNN, RNN states for actor.
        :param rnn_states_critic: (np.ndarray) if critic is RNN, RNN states for critic.
        :param masks: (np.ndarray) denotes points at which RNN states should be reset.
        :param available_actions: (np.ndarray) denotes which actions are available to agent
                                  (if None, all actions available)
        :param deterministic: (bool) whether the action should be mode of distribution or should be sampled.

        :return values: (torch.Tensor) value function predictions.
        :return actions: (torch.Tensor) actions to take.
        :return action_log_probs: (torch.Tensor) log probabilities of chosen actions.
        :return rnn_states_actor: (torch.Tensor) updated actor network RNN states.
        :return rnn_states_critic: (torch.Tensor) updated critic network RNN states.
        """
        guide_action,guide_action_log_probs=self.get_guide_action(cent_obs, deterministic)

        actions, action_log_probs, rnn_states_actor = self.actor(obs,
                                                                 guide_action,
                                                                 rnn_states_actor,
                                                                 masks,
                                                                 available_actions,
                                                                 deterministic)
        Mvalues = self.mcritic(cent_obs, guide_action,rnn_states_critic, masks)
        values, rnn_states_critic = self.critic(cent_obs, rnn_states_critic, masks)

        return values,Mvalues,actions, action_log_probs,guide_action,guide_action_log_probs, rnn_states_actor, rnn_states_critic
    def get_values(self, cent_obs,rnn_states_critic, masks):
        """
        Get value function predictions.
        :param cent_obs (np.ndarray): centralized input to the critic.
        :param rnn_states_critic: (np.ndarray) if critic is RNN, RNN states for critic.
        :param masks: (np.ndarray) denotes points at which RNN states should be reset.

        :return values: (torch.Tensor) value function predictions.
        """

        values, _ = self.critic(cent_obs, rnn_states_critic, masks)
        return values
   #用在训练trainer
    def evaluate_student(self,obs):
        guide_action_logits=self.student.get_logits(obs)
        return guide_action_logits
    def evaluate_guide_action(self, cent_obs,guide_action):

        guide_action_log_probs, guide_action_entropy, guide_action_mu, guide_action_std, guide_action_all_probs,guide_action_prob = self.coach.evaluate_guide_action(cent_obs,
            guide_action)


        return guide_action_log_probs, guide_action_entropy, guide_action_mu, guide_action_std, guide_action_all_probs,guide_action_prob
    def evaluate_actions(self, cent_obs, obs, guide_action,rnn_states_actor, rnn_states_critic, action, masks,
                         available_actions=None, active_masks=None):
        """
        Get action logprobs / entropy and value function predictions for actor update.
        :param cent_obs (np.ndarray): centralized input to the critic.
        :param obs (np.ndarray): local agent inputs to the actor.
        :param rnn_states_actor: (np.ndarray) if actor is RNN, RNN states for actor.
        :param rnn_states_critic: (np.ndarray) if critic is RNN, RNN states for critic.
        :param action: (np.ndarray) actions whose log probabilites and entropy to compute.
        :param masks: (np.ndarray) denotes points at which RNN states should be reset.
        :param available_actions: (np.ndarray) denotes which actions are available to agent
                                  (if None, all actions available)
        :param active_masks: (torch.Tensor) denotes whether an agent is active or dead.

        :return values: (torch.Tensor) value function predictions.
        :return action_log_probs: (torch.Tensor) log probabilities of the input actions.
        :return dist_entropy: (torch.Tensor) action distribution entropy for the given inputs.
        """

        action_log_probs, dist_entropy , action_mu, action_std, all_probs= self.actor.evaluate_actions(obs,
                                                                    guide_action,
                                                                    rnn_states_actor,
                                                                    action,
                                                                    masks,
                                                                    available_actions,
                                                                    active_masks)
        Mvalues = self.mcritic(cent_obs, guide_action, rnn_states_critic, masks)
        values, _ = self.critic(cent_obs, rnn_states_critic, masks)

        return values,Mvalues,action_log_probs, dist_entropy, action_mu, action_std, all_probs
    def eval_get_guide_action(self,obs,return_logits=False):
        guide_action = self.student(obs, return_logits)
        return guide_action

    #用于评价时的函数，act基于局部信息输出动作
    def act(self, obs,rnn_states_actor, masks, available_actions=None, deterministic=True,return_logits=False):
        """
        Compute actions using the given inputs.
        :param obs (np.ndarray): local agent inputs to the actor.
        :param rnn_states_actor: (np.ndarray) if actor is RNN, RNN states for actor.
        :param masks: (np.ndarray) denotes points at which RNN states should be reset.
        :param available_actions: (np.ndarray) denotes which actions are available to agent
                                  (if None, all actions available)
        :param deterministic: (bool) whether the action should be mode of distribution or should be sampled.
        """
        guide_action=self.eval_get_guide_action(obs, return_logits)
        actions, _, rnn_states_actor = self.actor(obs, guide_action,rnn_states_actor, masks, available_actions, deterministic)
        return actions, rnn_states_actor
