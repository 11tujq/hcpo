from .distributions import Categorical
import torch.nn as nn

class STUDENTLayer(nn.Module):
    """
       MLP Module to compute guide_action.
       :param guide_action_space: (gym.Space) guide_space.
       :param inputs_dim: (int) dimension of network input.
       :param use_orthogonal: (bool) whether to use orthogonal initialization.
       :param gain: (float) gain of the output layer of the network.
       """

    def __init__(self, guide_action_space, inputs_dim,use_orthogonal,gain, args=None):
        super(STUDENTLayer,self).__init__()
        guide_action_dim = guide_action_space.n

        self.guide_action_out = Categorical(inputs_dim, guide_action_dim,use_orthogonal, gain)

    def forward(self, x,return_logits=False):
        """
        Compute guide_action logprobs from given input.
        :param x: (torch.Tensor) input to network.
        :param return_logits:(bool) whether to get loss
        :param deterministic: (bool) whether to sample from action distribution or return the mode.

        :return guide_action: (torch.Tensor) guide_action to take.
        :return guide_action_log_probs: (torch.Tensor) log probabilities of taken guide_action
        """

        guide_action_logits = self.guide_action_out(x)

        if return_logits:
            guide_action_logits = guide_action_logits.logits
            return guide_action_logits  # 直接返回 logits（用于计算损失）
        else:
            guide_action = guide_action_logits.mode()



            return guide_action
