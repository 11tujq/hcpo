#!/bin/sh
env="StarCraft2"
map="8m_vs_9m"
algo="chatrpo"
exp="mlp"
running_max=20
kl_threshold=0.06
echo "env is ${env}, map is ${map}, algo is ${algo}, exp is ${exp}, max seed is ${seed_max}"
for seed in 2223 7665 1238;
do
    CUDA_VISIBLE_DEVICES=0 python train/train_smac_coach.py --env_name ${env} 
    --algorithm_name ${algo} --experiment_name ${exp} --map_name ${map} --running_id 1 \
    --gamma 0.95 --n_training_threads 32 --n_rollout_threads 20 --num_mini_batch 1 \
    --episode_length 160 --num_env_steps 10040000 --ppo_epoch 5 --stacked_frames 1 \
    --kl_threshold ${kl_threshold} --use_value_active_masks --use_eval --add_center_xy \
    --use_state_agent --accept_ratio 0.5 --clip_param 0.2 --critic_epoch 5 \
    --gae_lambda 0.95 --huber_delta 10.0 --ls_step 10 --max_grad_norm 10.0 --value_loss_coef 1 \
    --critic_lr 0.0005 --std_x_coef 1 --std_y_coef 0.5 --weight_decay 0 --render_episodes 10 --seed ${seed}
done