#!/bin/sh
env="mpe"
scenario="simple_speaker_listener_v3" # choose from simple_spread_v2, simple_reference_v2, simple_speaker_listener_v3
continuous_actions=True
algo="chatrpo"
exp="mlp"
running_max=1
kl_threshold=0.005
guide_action_kl_threshold=1e-4
echo "env is ${env}, scenario is ${scenario}, algo is ${algo}, exp is ${exp}, max seed is ${seed_max}"
for seed in 2223 7665 1238;
do
    echo "the ${number}-th running:"
    CUDA_VISIBLE_DEVICES=0 python train/train_mpe_coach.py --accept_ratio 0.5 --backtrack_coeff 0.8 \
    --ls_step 10 --clip_param 0.2 --critic_epoch 5 --max_grad_norm 10.0\
   --gae_lambda 0.95 --gamma 0.99 --use_eval \
    --huber_delta 10.0 --value_loss_coef 1 --value_loss_coef 1 \
     --env_name ${env}  --algorithm_name ${algo} --experiment_name ${exp} --scenario ${scenario} \
    --std_x_coef 1 --std_y_coef 0.5  --n_training_threads 8 \
      --n_rollout_threads 20 --num_mini_batch 1 --episode_length 200 --num_env_steps 10000000 --ppo_epoch 5 \
       --kl_threshold ${kl_threshold} --guide_action_kl_threshold ${guide_action_kl_threshold} \
 --hidden_size 128 --lr 0.0005 --critic_lr 0.0005 \
       --weight_decay 0 --opti_eps 0.00001 --gain 0.01 --seed ${seed} --running_id 1 --use_value_active_masks --use_eval --add_center_xy --use_state_agent --share_policy
done