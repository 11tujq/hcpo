#!/bin/sh
env="mujoco"
scenario="Hopper-v2"
agent_conf="3x1"
agent_obsk=0
algo="hatrpo"
exp="mlp"
kl_threshold=0.005
guide_action_kl_threshold=1e-4
echo "env is ${env}, scenario is ${scenario}, algo is ${algo}, exp is ${exp}, max seed is ${seed_max}"
for seed in 2223 7665 1238;
do
    CUDA_VISIBLE_DEVICES=0 python train/train_mujoco_coach.py --env_name ${env}\
     --algorithm_name ${algo} --experiment_name ${exp} --scenario ${scenario} \
      --agent_conf ${agent_conf} --agent_obsk ${agent_obsk} --lr 0.0005 --critic_lr 5e-4 \
      --std_x_coef 1 --std_y_coef 0.5 --running_id 1 --n_training_threads 8 \
      --n_rollout_threads 20 --num_mini_batch 1 --episode_length 200 --num_env_steps 10000000 \
      --ppo_epoch 5 --kl_threshold ${kl_threshold} --guide_action_kl_threshold ${guide_action_kl_threshold} \
    --use_eval --add_center_xy --use_state_agent \
      --accept_ratio 0.5 --backtrack_coeff 0.8 --clip_param 0.2 --critic_epoch 5 --gae_lambda 0.95 \
      --gamma 0.99 --huber_delta 10 --ls_step 10 --max_grad_norm 10 --gain 0.01 --hidden_size 128 \
      --opti_eps 0.00001 --weight_decay 0 --seed ${seed}
done
