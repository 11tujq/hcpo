

# <center>Hierarchical Conductor-based Policy Optimization in Multi-agent Reinforcement Learning</center>
## Instruction
The overall framework of HCPO. 
- Centralized training: A two-level policy updatemechanism with a virtual centralized conductor is proposed, leveraging well-designed advantage functions.
- Policy update for agents: Here, local agents’ policies denoted by orange ellipses are optimized through sequential updates, and local conductors’ policies denoted by blue rectangles are optimized through the cross-entropy method. During this iteration, policies with shaded outlines represent updated versions, while those without shading indicate unmodified ones. 
- Decentralized execution: HCPO enables agents to make decisions based only on local information.
![](/imgs/2025-07-12/AjP0nFdqs6ru6amb.jpeg)
## Intallation
### create conda environment
```
conda create -n hcpo python=3.8
conda activate hcpo
cd HCPO
pip install -e .
```

### install environments dependecies
 In our paper,we evaluate our algorithm on three benchmarks ([SMAC](https://github.com/oxwhirl/smac),[MAMuJoCo](https://github.com/schroederdewitt/multiagent_mujoco), [MPE](https://pettingzoo.farama.org/environments/mpe/)) and they can be used directly. You may choose to install the dependencies to the environments you want to use. 

**Install SMAC** 
Please follow [the official instructions](https://github.com/oxwhirl/smac) to install SMAC.
And you also can use```bash install_sc2.sh``` to download it easily.
**Install MPE** 
```shell 
pip install pettingzoo==1.22.2 
pip install supersuit==3.7.0 
```
**Install MuJoCo**

First, follow the instructions on https://github.com/openai/mujoco-py, https://www.roboti.us/, and https://github.com/deepmind/mujoco to download the right version of mujoco you need.

Second, `mkdir ~/.mujoco`.

Third, move the .tar.gz or .zip to `~/.mujoco`, and extract it using `tar -zxvf` or `unzip`.

Fourth, add the following line to the `.bashrc`:

```shell
export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/home/<user>/.mujoco/<folder-name, e.g. mujoco210, mujoco-2.2.1>/bin
```

Fifth, run the following command:

```shell
sudo apt install libosmesa6-dev libgl1-mesa-glx libglfw3
pip install mujoco
pip install gym[mujoco]
sudo apt-get update -y
sudo apt-get install -y patchelf
```

**Install Dependencies of MAMuJoCo**

First follow the instructions above to install MuJoCo. Then run the following commands.

```shell
pip install "mujoco-py>=2.1.2.14"
pip install "Jinja2>=3.0.3"
pip install "glfw>=2.5.1"
pip install "Cython>=0.29.28"
```
## train
If you have installed all the required dependencies, you can execute the following command to initiate a quick training.
```shell
cd scripts
./train_smac.sh
./train_mujoco.sh
./train_mpe.sh
```
